package com.zanchenko.alexey.sfgDependencyInjetion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SfgDependencyInjetionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SfgDependencyInjetionApplication.class, args);
	}

}
