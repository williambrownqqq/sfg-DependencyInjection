package com.zanchenko.alexey.sfgDependencyInjetion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SfgDependencyInjetionApplicationTests {

	@Test
	void contextLoads() {
	}

}
